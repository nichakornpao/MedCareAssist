// src/shared/patientState.js

const STATUS_KEY = "medcare_patient_status";

// อ่านสถานะล่าสุด
export function getPatientStatus() {
  const raw = localStorage.getItem(STATUS_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

// อัปเดตสถานะ (merge)
export function updatePatientStatus(patch) {
  const current = getPatientStatus();
  const next = { ...current, ...patch };
  localStorage.setItem(STATUS_KEY, JSON.stringify(next));
  return next;
}
