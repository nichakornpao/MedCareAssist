// src/pages/caregiver/CaregiverGPS.jsx
import React, { useEffect, useState } from "react";
import { getPatientStatus } from "../../shared/patientState";

export default function CaregiverGPS() {
  const [location, setLocation] = useState(null);

  useEffect(() => {
    const status = getPatientStatus();
    setLocation(status.lastLocation || null);

    // เผื่อหลายแท็บ sync
    const onStorage = (e) => {
      if (e.key === "medcare_patient_status") {
        const updated = getPatientStatus();
        setLocation(updated.lastLocation || null);
      }
    };
    window.addEventListener("storage", onStorage);

    return () => window.removeEventListener("storage", onStorage);
  }, []);

  return (
    <main className="container dashboard">
      <h1 className="page-title">ตำแหน่งผู้ป่วย (GPS)</h1>
      <p className="page-sub">อัปเดตจากผู้ป่วยแบบเรียลไทม์</p>

      <section className="card" style={{ minHeight: "300px" }}>
        {!location ? (
          <p>ยังไม่มีการส่งตำแหน่งจากผู้ป่วย</p>
        ) : (
          <div>
            <h3>ตำแหน่งล่าสุด</h3>
            <p>
              Latitude: <b>{location.latitude.toFixed(5)}</b>
              <br />
              Longitude: <b>{location.longitude.toFixed(5)}</b>
              <br />
              เวลา: {location.time}
            </p>

            <iframe
              title="patient-map"
              width="100%"
              height="300"
              style={{ borderRadius: "14px", marginTop: "10px" }}
              src={`https://maps.google.com/maps?q=${location.latitude},${location.longitude}&z=16&output=embed`}
            ></iframe>
          </div>
        )}
      </section>
    </main>
  );
}
