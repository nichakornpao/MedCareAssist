// src/pages/caregiver/CaregiverDashboard.jsx
import React, { useEffect, useState } from "react";
import { getPatientStatus } from "../../shared/patientState";

const MEDS_KEY = "medcare_meds_full";

function loadMeds() {
  const raw = localStorage.getItem(MEDS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

// หา "ยาถัดไป" แบบเดียวกับฝั่งผู้ป่วย
function findNextMed() {
  const meds = loadMeds();
  if (!meds.length) return null;

  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  let nearest = null;
  let minDiff = Infinity;

  meds.forEach((m) => {
    if (!m.time) return;
    const [h, mm] = m.time.split(":").map(Number);
    const t = h * 60 + mm;
    const diff = t - nowMinutes;
    if (diff >= 0 && diff < minDiff) {
      minDiff = diff;
      nearest = m;
    }
  });

  return nearest;
}

export default function CaregiverDashboard() {
  const [status, setStatus] = useState(getPatientStatus());
  const [nextMed, setNextMed] = useState(findNextMed());

  const refreshStatus = () => {
    setStatus(getPatientStatus());
    setNextMed(findNextMed());
  };

  useEffect(() => {
    // โหลดครั้งแรก
    refreshStatus();

    // ถ้ามีการเปลี่ยน localStorage จากอีกแท็บ (เช่น เครื่องผู้ป่วย)
    const onStorage = (e) => {
      if (e.key === "medcare_patient_status") {
        refreshStatus();
      }
    };
    window.addEventListener("storage", onStorage);

    // กันเหนียว: รีเฟรชทุก 10 วิ
    const id = setInterval(refreshStatus, 10000);

    return () => {
      window.removeEventListener("storage", onStorage);
      clearInterval(id);
    };
  }, []);

  return (
    <main className="container dashboard">
      <section className="page-header">
        <div>
          <h1 className="page-title">แดชบอร์ดผู้ดูแล</h1>
          <p className="page-sub">
            ดูสถานะการทานยา อาการ และตำแหน่งล่าสุดของผู้ป่วยแบบเรียลไทม์
          </p>
        </div>
      </section>

      {/* การ์ดสถานะการทานยา */}
      <section className="card">
        <h3>สถานะการทานยา</h3>

        <p>
          {status.lastMedTakenAt
            ? `ผู้ป่วยกด "ฉันกินยาแล้ว" เวลา ${status.lastMedTakenAt}`
            : "ยังไม่มีการกดปุ่มฉันกินยาแล้วในวันนี้"}
        </p>

        {nextMed ? (
          <p>
            ยาถัดไป: {nextMed.name} เวลา {nextMed.time}
            {nextMed.period ? ` (${nextMed.period})` : ""}
          </p>
        ) : (
          <p>วันนี้ไม่มีเวลายาที่เหลือแล้ว</p>
        )}
      </section>

      {/* การ์ดอาการรายวัน */}
      <section className="card">
        <h3>อาการรายวัน</h3>

        {status.lastSymptom ? (
          <>
            <p>- {status.lastSymptom}</p>
            {status.lastSymptomAt && (
              <p className="note-sub">แจ้งเวลา {status.lastSymptomAt}</p>
            )}
          </>
        ) : (
          <p>ยังไม่มีการแจ้งอาการจากผู้ป่วย</p>
        )}
      </section>

      {/* ปุ่มไปดู GPS / รายละเอียดอาการ */}
   <section className="caregiver-actions">
  <button
    className="btn-primary"
    onClick={() => (window.location.href = "/caregiver/gps")}
  >
    ดูตำแหน่งผู้ป่วย (GPS)
  </button>

  <button
    className="btn-secondary"
    onClick={() => (window.location.href = "/caregiver/symptoms")}
  >
    บันทึก/ดูอาการ
  </button>
</section>

    </main>
  );
}
