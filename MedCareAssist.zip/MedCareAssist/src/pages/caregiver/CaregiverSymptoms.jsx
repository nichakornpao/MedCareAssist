import React, { useState, useEffect } from "react";

const STORAGE_KEY = "medcare_symptoms";

export default function CaregiverSymptoms() {
  // โหลดอาการจาก localStorage ครั้งแรก
  const [notes, setNotes] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [symptom, setSymptom] = useState("");

  // เซฟลง localStorage ทุกครั้งที่ notes เปลี่ยน
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
  }, [notes]);

  const addSymptom = () => {
    if (!symptom.trim()) return;

    const newNote = {
      id: Date.now(),
      text: symptom.trim(),
      time: new Date().toLocaleString("th-TH"),
    };

    // ใส่รายการใหม่ไว้บนสุด
    setNotes([newNote, ...notes]);
    setSymptom("");
  };

  const deleteSymptom = (id) => {
    setNotes(notes.filter((n) => n.id !== id));
  };

  return (
    <main className="container dashboard">
      <section className="page-header">
        <div>
          <h1 className="page-title">บันทึกอาการผู้ป่วย</h1>
          <p className="page-sub">
            ผู้ดูแลใช้บันทึกอาการ เช่น ปวดหัว เวียนหัว นอนไม่หลับ ฯลฯ
          </p>
        </div>
      </section>

      <section className="card">
        <h3>เพิ่มอาการวันนี้</h3>

        <input
          className="input"
          placeholder="เช่น เวียนหัวเวลาเดิน นอนไม่หลับติดต่อกัน 2 คืน"
          value={symptom}
          onChange={(e) => setSymptom(e.target.value)}
        />

        <button className="btn-primary" type="button" onClick={addSymptom}>
          + เพิ่มบันทึกอาการ
        </button>
      </section>

      <section className="card">
        <h3>อาการย้อนหลัง</h3>

        {notes.length === 0 && (
          <p className="page-sub">
            ยังไม่มีการบันทึกอาการ ระบบจะจำอาการที่บันทึกไว้ให้โดยอัตโนมัติ
          </p>
        )}

        <ul className="notes-list">
          {notes.map((n) => (
            <li key={n.id}>
              <span className="dot-status dot-blue" />
              <div>
                <div className="note-title">{n.text}</div>
                <div className="note-sub">{n.time}</div>
              </div>
              <button
                className="btn-danger"
                style={{ marginLeft: "auto" }}
                onClick={() => deleteSymptom(n.id)}
              >
                ลบ
              </button>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
