// src/pages/clinic/ClinicReports.jsx
import React, { useEffect, useMemo, useState } from "react";
import { getPatientStatus } from "../../shared/patientState";

const MEDS_KEY = "medcare_meds_full";
const MED_HISTORY_KEY = "medcare_med_history";
const SYMPTOM_HISTORY_KEY = "medcare_symptom_history";

const getTodayStr = () => new Date().toISOString().slice(0, 10);

function loadJSON(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
}

function loadMeds() {
  const raw = localStorage.getItem(MEDS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export default function ClinicReports() {
  const today = getTodayStr();

  // ---------- state สำหรับข้อมูลที่ต้องอัปเดตตลอด ----------
  const [status, setStatus] = useState(getPatientStatus());
  const [meds, setMeds] = useState(loadMeds());
  const [medHistory, setMedHistory] = useState(loadJSON(MED_HISTORY_KEY));
  const [symptomHistory, setSymptomHistory] = useState(
    loadJSON(SYMPTOM_HISTORY_KEY)
  );

  // ฟังก์ชันโหลดข้อมูลจาก localStorage มารวมทีเดียว
  const refreshFromStorage = () => {
    setStatus(getPatientStatus());
    setMeds(loadMeds());
    setMedHistory(loadJSON(MED_HISTORY_KEY));
    setSymptomHistory(loadJSON(SYMPTOM_HISTORY_KEY));
  };

  // ให้รีเฟรชทุก 3 วินาที + เวลา storage เปลี่ยน
  useEffect(() => {
    refreshFromStorage(); // โหลดตอนเข้า

    const id = setInterval(refreshFromStorage, 3000);

    const onStorage = (e) => {
      if (
        !e.key ||
        e.key === MEDS_KEY ||
        e.key === MED_HISTORY_KEY ||
        e.key === SYMPTOM_HISTORY_KEY
      ) {
        refreshFromStorage();
      }
    };
    window.addEventListener("storage", onStorage);

    return () => {
      clearInterval(id);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  // ---- วิเคราะห์การทานยา "วันนี้" ----
  const medSummaryToday = useMemo(() => {
    const medsToday = meds.filter((m) => m.time); // สมมติว่า schedule ทุกวันเหมือนกัน
    const scheduledCount = medsToday.length;

    const todayHistory = medHistory.filter((h) => h.date === today);

    // key สำหรับ match ว่าตัวนี้กินแล้ว
    const takenKeys = new Set();
    let onTimeCount = 0;
    let lateCount = 0;

    todayHistory.forEach((h) => {
      if (!h.scheduledTime) return;
      const key = `${h.medName}|${h.scheduledTime}`;
      takenKeys.add(key);

      if (
        typeof h.scheduledMinutes === "number" &&
        typeof h.takenMinutes === "number"
      ) {
        const diff = Math.abs(h.takenMinutes - h.scheduledMinutes);
        if (diff <= 30) onTimeCount += 1;
        else lateCount += 1;
      }
    });

    const takenCount = takenKeys.size;
    const missedCount = Math.max(0, scheduledCount - takenCount);
    const onTimePercent =
      scheduledCount > 0 ? Math.round((onTimeCount / scheduledCount) * 100) : 0;

    return {
      scheduledCount,
      takenCount,
      missedCount,
      onTimeCount,
      lateCount,
      onTimePercent,
      todayHistory,
    };
  }, [meds, medHistory, today]);

  // ---- ประวัติการทานยา 7 รายการล่าสุด ----
  const recentMedHistory = useMemo(
    () =>
      [...medHistory]
        .sort((a, b) => (a.date > b.date ? -1 : 1))
        .slice(0, 7),
    [medHistory]
  );

  // ---- ประวัติอาการ 7 รายการล่าสุด ----
  const recentSymptoms = useMemo(
    () =>
      [...symptomHistory]
        .sort((a, b) => (a.date > b.date ? -1 : 1))
        .slice(0, 7),
    [symptomHistory]
  );

  return (
    <main className="container dashboard">
      <section className="page-header">
        <div>
          <h1 className="page-title">รายงานสำหรับคลินิก/โรงพยาบาล</h1>
          <p className="page-sub">
            สรุปการทานยาและอาการย้อนหลังจากระบบ MedCare Assist
          </p>
        </div>
      </section>

      {/* บล็อกสรุปภาพรวมวันนี้ */}
      <section className="card clinic-summary">
        <h3>สรุปการทานยาวันนี้</h3>
        <div className="clinic-metrics">
          <div className="metric-pill">
            <div className="metric-label">จำนวนยาที่กำหนด</div>
            <div className="metric-value">
              {medSummaryToday.scheduledCount} รายการ
            </div>
          </div>
          <div className="metric-pill">
            <div className="metric-label">ทานแล้ว</div>
            <div className="metric-value">
              {medSummaryToday.takenCount} ครั้ง
            </div>
          </div>
          <div className="metric-pill">
            <div className="metric-label">ลืมหรือยังไม่ได้ทาน</div>
            <div className="metric-value">
              {medSummaryToday.missedCount} ครั้ง
            </div>
          </div>
          <div className="metric-pill">
            <div className="metric-label">ทานตรงเวลาประมาณ</div>
            <div className="metric-value">
              {medSummaryToday.onTimePercent}%
            </div>
          </div>
        </div>
      </section>

      {/* ตารางประวัติการทานยา */}
      <section className="card">
        <h3>ประวัติการทานยาล่าสุด</h3>
        {recentMedHistory.length === 0 ? (
          <p>ยังไม่มีข้อมูลประวัติการทานยา</p>
        ) : (
          <table className="clinic-table">
            <thead>
              <tr>
                <th>วันที่</th>
                <th>ชื่อยา (คาดว่า)</th>
                <th>เวลาที่กำหนด</th>
                <th>เวลาที่กดว่าทานแล้ว</th>
              </tr>
            </thead>
            <tbody>
              {recentMedHistory.map((h, idx) => (
                <tr key={idx}>
                  <td>{h.date}</td>
                  <td>{h.medName}</td>
                  <td>{h.scheduledTime || "-"}</td>
                  <td>{h.takenAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {/* ประวัติอาการย้อนหลัง */}
      <section className="card">
        <h3>อาการย้อนหลังล่าสุด</h3>
        {recentSymptoms.length === 0 ? (
          <p>ยังไม่มีการแจ้งอาการจากผู้ป่วย</p>
        ) : (
          <ul className="clinic-symptom-list">
            {recentSymptoms.map((s, idx) => (
              <li key={idx}>
                <span className="symptom-date">{s.date}</span>
                <span className="symptom-text">
                  {s.text} เวลา {s.time}
                </span>
              </li>
            ))}
          </ul>
        )}

        {/* แสดงอาการล่าสุดจาก patientState เพิ่มเติม */}
        {status.lastSymptom && (
          <p className="note-sub">
            อาการล่าสุด: {status.lastSymptom} เวลา {status.lastSymptomAt}
          </p>
        )}
      </section>
    </main>
  );
}
