import React, { useEffect, useState } from "react";
import { getPatientStatus } from "../../shared/patientState";

export default function CaregiverDashboard() {
  const [status, setStatus] = useState(getPatientStatus());

  // ฟังก์ชันโหลดสถานะล่าสุด
  const refreshStatus = () => {
    setStatus(getPatientStatus());
  };

  useEffect(() => {
    // ดึงครั้งแรก
    refreshStatus();

    // ถ้าอีกแท็บเขียน localStorage → event นี้จะยิง
    const onStorage = (e) => {
      if (e.key === "medcare_patient_status") {
        refreshStatus();
      }
    };
    window.addEventListener("storage", onStorage);

    // กันเหนียว: เช็คทุก 10 วิ
    const id = setInterval(refreshStatus, 10000);

    return () => {
      window.removeEventListener("storage", onStorage);
      clearInterval(id);
    };
  }, []);

  return (
    <main className="container dashboard">
      <section className="page-header">
        <div>
          <h1 className="page-title">แดชบอร์ดผู้ดูแล</h1>
          <p className="page-sub">
            ดูสถานะผู้ป่วยแบบเรียลไทม์จากการกดปุ่มของผู้ป่วย
          </p>
        </div>
      </section>

      <section className="card">
        <h3>สถานะล่าสุดจากผู้ป่วย</h3>

        <div className="notes-list">
          <div>
            <div className="note-title">
              กินยาล่าสุด:
              {" "}
              {status.lastMedTakenAt ? (
                <span>ทานแล้ว ✔ เวลา {status.lastMedTakenAt}</span>
              ) : (
                <span>ยังไม่มีการกด "ฉันกินยาแล้ว"</span>
              )}
            </div>
          </div>

          <div>
            <div className="note-title">
              อาการล่าสุด:
              {" "}
              {status.lastSymptom ? status.lastSymptom : "ยังไม่มีการแจ้งอาการ"}
            </div>
            {status.lastSymptomAt && (
              <div className="note-sub">เวลา {status.lastSymptomAt}</div>
            )}
          </div>

          <div>
            <div className="note-title">ตำแหน่งล่าสุดของผู้ป่วย</div>
            {status.lastLocation ? (
              <div className="note-sub">
                Lat: {status.lastLocation.latitude.toFixed(5)} / Lng:{" "}
                {status.lastLocation.longitude.toFixed(5)} เวลา{" "}
                {status.lastLocation.time}
              </div>
            ) : (
              <div className="note-sub">ยังไม่มีการส่งตำแหน่ง</div>
            )}
          </div>
        </div>
      </section>

      {/* ยูสามารถต่อยอดเอาบล็อกเก่า (กราฟ, ตารางยา, บันทึกการดูแล) มาวางต่อด้านล่างนี้ได้เลย */}
    </main>
  );
}
