// src/pages/patient/PatientHome.jsx
import React, { useState, useEffect, useRef } from "react";
import { getPatientStatus, updatePatientStatus } from "../../shared/patientState";

const MEDS_KEY = "medcare_meds_full";

export default function PatientHome() {
  const [lastAction, setLastAction] = useState("");
  const [nextAlarmText, setNextAlarmText] = useState("");
  const audioRef = useRef(null);

  // โหลดสถานะล่าสุด
  useEffect(() => {
    const status = getPatientStatus();
    if (status.lastAction) {
      setLastAction(status.lastAction);
    }
  }, []);

  // อ่านรายการยาจาก localStorage
  const loadMeds = () => {
    const raw = localStorage.getItem(MEDS_KEY);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  };

  // หายาที่ "ถึงคิวถัดไป" ที่ยังไม่ได้กินในวันนี้
  const getUpcomingMed = () => {
    const meds = loadMeds();
    const now = new Date();
    const nowMins = now.getHours() * 60 + now.getMinutes();
    const today = now.toISOString().split("T")[0];

    let nearest = null;
    let nearestDiff = Infinity;

    meds.forEach((m) => {
      if (!m.time) return;
      if (m.lastTakenDate === today) return; // กินแล้ววันนี้ ข้าม

      const [h, mm] = m.time.split(":").map(Number);
      const medMins = h * 60 + mm;
      const diff = medMins - nowMins;

      if (diff >= 0 && diff < nearestDiff) {
        nearestDiff = diff;
        nearest = m;
      }
    });

    return nearest;
  };

  // ระบบเช็คเตือนยาอัตโนมัติทุก 30 วินาที
  useEffect(() => {
    const triggerAlarm = (med) => {
      // เล่นเสียง
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(() => {});
      }
      // เตือนบนจอ
      alert(`ถึงเวลาทานยาแล้วค่ะ: ${med.name} เวลา ${med.time}`);
    };

    const checkAlarms = () => {
      const meds = loadMeds();
      if (!meds.length) {
        setNextAlarmText("ยังไม่มีการตั้งยา");
        return;
      }

      const now = new Date();
      const nowMins = now.getHours() * 60 + now.getMinutes();
      const today = now.toISOString().split("T")[0];

      let nearest = null;
      let nearestDiff = Infinity;

      meds.forEach((m) => {
        if (!m.time) return;

        const [h, mm] = m.time.split(":").map(Number);
        const medMins = h * 60 + mm;
        const diff = medMins - nowMins;

        // ถ้ากินแล้ววันนี้ ข้าม
        if (m.lastTakenDate === today) return;

        // หายาที่ใกล้ที่สุดถัดไป
        if (diff >= 0 && diff < nearestDiff) {
          nearestDiff = diff;
          nearest = m;
        }

        // ถึงเวลาในช่วง +/- 2 นาที และยังไม่ได้กินวันนี้ → เตือน
        if (Math.abs(diff) <= 2 && m.lastTakenDate !== today) {
          triggerAlarm(m);
        }
      });

      if (nearest) {
        setNextAlarmText(
          `ยาที่ต้องทานถัดไป ${nearest.name} เวลา ${nearest.time}${
            nearest.period ? ` (${nearest.period})` : ""
          }`
        );
      } else {
        setNextAlarmText("วันนี้ทานยาครบแล้ว");
      }
    };

    checkAlarms(); // เช็คครั้งแรก
    const id = setInterval(checkAlarms, 30000);
    return () => clearInterval(id);
  }, []);

  // ผู้ป่วยกด "ฉันกินยาแล้ว"
  const handleTakeMedicine = () => {
    const meds = loadMeds();
    const now = new Date();
    const today = now.toISOString().split("T")[0];
    const time = now.toLocaleTimeString("th-TH");

    const upcoming = getUpcomingMed();

    if (!upcoming) {
      const text =
        'กด "ฉันกินยาแล้ว" แต่วันนี้ไม่มีรายการยาที่ต้องทานแล้ว';
      setLastAction(text);
      updatePatientStatus({ lastAction: text });
      alert("วันนี้ทานยาครบแล้ว ไม่มีรายการที่ต้องทานเพิ่มเติมค่ะ");
      return;
    }

    const updated = meds.map((m) =>
      m.name === upcoming.name && m.time === upcoming.time
        ? { ...m, lastTakenDate: today, lastTakenTime: time }
        : m
    );

    localStorage.setItem(MEDS_KEY, JSON.stringify(updated));

    const text = `กด "ฉันกินยาแล้ว" เวลา ${time}`;
    setLastAction(text);
    updatePatientStatus({
      lastMedTakenAt: time,
      lastAction: text,
    });

    alert(`บันทึกแล้วค่ะ ✔ คุณได้ทานยา ${upcoming.name} เวลา ${time}`);
  };

  // ผู้ป่วยกด "ฉันรู้สึกไม่สบาย"
  const handleSymptom = () => {
    const symptom = "รู้สึกไม่สบาย";
    const time = new Date().toLocaleTimeString("th-TH");
    const text = `${symptom} เวลา ${time}`;
    setLastAction(text);
    updatePatientStatus({
      lastSymptom: symptom,
      lastSymptomAt: time,
      lastAction: text,
    });
  };

  // ผู้ป่วยกด "ฉันอยู่ที่ไหน?"
  const handleWhereAmI = () => {
    if (!navigator.geolocation) {
      alert("เครื่องนี้ไม่รองรับ GPS");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const time = new Date().toLocaleTimeString("th-TH");
        const text = `ตำแหน่งปัจจุบัน: ${latitude.toFixed(
          5
        )}, ${longitude.toFixed(5)} เวลา ${time}`;
        setLastAction(text);
        updatePatientStatus({
          lastLocation: { latitude, longitude, time },
          lastAction: text,
        });
        alert("ส่งตำแหน่งให้ผู้ดูแลเรียบร้อยแล้วค่ะ");
      },
      () => {
        alert("ไม่สามารถดึงตำแหน่งได้ กรุณาเปิด GPS");
      }
    );
  };

  return (
    <main className="patient-screen">
      {/* ไฟล์เสียงเตือนยา (เอา med-alert.mp3 ไปไว้ใน public/ เองได้) */}
      <audio ref={audioRef} src="/med-alert.mp3" preload="auto" />

      <p className="big-sub">กดปุ่มใหญ่ ๆ เพื่อแจ้งให้ผู้ดูแลทราบ</p>

      {nextAlarmText && (
        <div className="patient-next-alarm">🔔 {nextAlarmText}</div>
      )}

      <button className="big-btn big-btn-eat" onClick={handleTakeMedicine}>
        💊 ฉันกินยาแล้ว
      </button>

      <button className="big-btn big-btn-sick" onClick={handleSymptom}>
        😵 ฉันรู้สึกไม่สบาย
      </button>

      <button className="big-btn big-btn-sos" onClick={handleWhereAmI}>
        📍 ฉันอยู่ที่ไหน?
      </button>

      {lastAction && (
        <div className="patient-last-action">ล่าสุด: {lastAction}</div>
      )}
    </main>
  );
}
