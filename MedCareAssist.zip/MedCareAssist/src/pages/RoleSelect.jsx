// src/pages/RoleSelect.jsx
import React from "react";
import { Link } from "react-router-dom";

export default function RoleSelect() {
  return (
    <main className="container role-select">
      <section className="page-header">
        <div>
          <h1 className="page-title">เลือกโหมดการใช้งาน</h1>
          <p className="page-sub">
            เลือกบทบาทให้ตรงกับผู้ใช้งานในระบบ MedCare Assist
          </p>
        </div>
      </section>

      <section className="role-grid">
        {/* ผู้ป่วย */}
        <article className="role-card role-patient">
          <div className="role-tag">สำหรับผู้ป่วย</div>
          <h2>โหมดผู้ป่วย</h2>
          <p>
            หน้าจอปุ่มใหญ่ เหมาะกับผู้สูงอายุหรือผู้ป่วยอัลไซเมอร์
            กดง่ายไม่ซับซ้อน มีปุ่มแจ้งกินยา ไม่สบาย และขอส่งตำแหน่ง
          </p>
          <ul className="role-list">
            <li>💊 ปุ่ม “ฉันกินยาแล้ว”</li>
            <li>😵 ปุ่มแจ้ง “ฉันรู้สึกไม่สบาย”</li>
            <li>📍 ปุ่ม “ฉันอยู่ที่ไหน?” ส่ง GPS ให้ผู้ดูแล</li>
          </ul>
          <Link to="/patient" className="role-btn">
            เข้าโหมดผู้ป่วย
          </Link>
        </article>

        {/* ผู้ดูแล */}
        <article className="role-card role-caregiver">
          <div className="role-tag">สำหรับญาติ/ผู้ดูแล</div>
          <h2>โหมดผู้ดูแล</h2>
          <p>
            ดูสถานะผู้ป่วยแบบเรียลไทม์ จัดการยา ตั้งเวลาแจ้งเตือน
            และดูอาการที่ผู้ป่วยแจ้งเข้ามาในแต่ละวัน
          </p>
          <ul className="role-list">
            <li>📊 แดชบอร์ดสุขภาพรายวัน</li>
            <li>💊 จัดการยาและเวลาเตือน</li>
            <li>📍 ดูตำแหน่งล่าสุดของผู้ป่วย</li>
          </ul>
          <Link to="/caregiver" className="role-btn">
            เข้าโหมดผู้ดูแล
          </Link>
        </article>

        {/* คลินิก / โรงพยาบาล */}
        <article className="role-card role-clinic">
          <div className="role-tag">สำหรับคลินิก / โรงพยาบาล</div>
          <h2>โหมดคลินิก</h2>
          <p>
            ใช้ดูรายงานการใช้ยาและอาการย้อนหลังของผู้ป่วย
            เพื่อช่วยคุณหมอปรับแผนการรักษาและกำหนดวันนัดหมายที่เหมาะสม
          </p>
          <ul className="role-list">
            <li>📄 รายงานประวัติการทานยา</li>
            <li>🩺 สรุปอาการย้อนหลัง</li>
            <li>📅 ข้อมูลช่วยวางแผนนัดหมาย</li>
          </ul>
          <Link to="/clinic" className="role-btn">
            เข้าโหมดคลินิก
          </Link>
        </article>
      </section>
    </main>
  );
}
