// src/pages/Dashboard.jsx
import React from "react";
import StatCard from "../components/StatCard";
import CardBox from "../components/CardBox";

export default function Dashboard() {
  return (
    <main className="container dashboard">
      {/* HERO */}
      <section className="hero-card">
        <div className="hero-main">
          <div>
            <div className="chip chip-soft">ภาพรวมวันนี้</div>
            <h2 className="hero-title">สวัสดีค่ะ คุณสมใจ นอนดี 🩺</h2>
            <p className="hero-sub">
              นี่คือสรุปข้อมูลสุขภาพและการทานยาของวันนี้
            </p>

            <div className="hero-tags">
              <span className="chip">สัญญาณชีพปกติ</span>
              <span className="chip chip-outline">มีเตือนทานยาเวลา 19:00 น.</span>
            </div>
          </div>

          <div className="hero-pulse">
            <div className="hero-ring" />
            <div className="hero-pulse-content">
              <div className="hero-pulse-label">ชีพจรขณะพัก</div>
              <div className="hero-pulse-value">78</div>
              <div className="hero-pulse-sub">ครั้งต่อนาที • อยู่ในเกณฑ์ปกติ</div>
            </div>
          </div>
        </div>
      </section>

      {/* STAT CARDS */}
      <section className="stat-grid">
        <StatCard
          label="ความดันโลหิต"
          value="118 / 76"
          unit="mmHg"
          status="ปกติ"
          accent="green"
        />
        <StatCard
          label="ระดับน้ำตาลหลังอาหาร"
          value="132"
          unit="mg/dL"
          status="ควบคุมได้"
          accent="blue"
        />
        <StatCard
          label="จำนวนก้าววันนี้"
          value="4,820"
          unit="ก้าว"
          status="ใกล้ถึงเป้าหมาย"
          accent="orange"
        />
      </section>

      <section className="bottom-grid">
        {/* TODAY SCHEDULE */}
        <CardBox title="ตารางกิจกรรมและการทานยาวันนี้" pill="เวลาตามเขตประเทศไทย">
          <div className="timeline">
            <div className="timeline-item">
              <div className="timeline-time">07:30</div>
              <div className="timeline-dot dot-green" />
              <div className="timeline-content">
                <div className="timeline-title">ทานยาความดันเช้า</div>
                <div className="timeline-sub">Amlodipine 5 mg • หลังอาหารเช้า</div>
              </div>
            </div>

            <div className="timeline-item">
              <div className="timeline-time">12:00</div>
              <div className="timeline-dot dot-blue" />
              <div className="timeline-content">
                <div className="timeline-title">พักผ่อนและดื่มน้ำ</div>
                <div className="timeline-sub">ดื่มน้ำ 1 แก้ว • วัดความดันหากรู้สึกเวียนหัว</div>
              </div>
            </div>

            <div className="timeline-item">
              <div className="timeline-time">15:30</div>
              <div className="timeline-dot dot-purple" />
              <div className="timeline-content">
                <div className="timeline-title">เดินออกกำลังกายเบา ๆ</div>
                <div className="timeline-sub">เดินช้า ๆ 15–20 นาที ในบริเวณบ้าน</div>
              </div>
            </div>

            <div className="timeline-item">
              <div className="timeline-time">19:00</div>
              <div className="timeline-dot dot-orange" />
              <div className="timeline-content">
                <div className="timeline-title">ทานยาคุมระดับน้ำตาลเย็น</div>
                <div className="timeline-sub">Metformin 500 mg • หลังอาหารเย็น</div>
              </div>
            </div>
          </div>
        </CardBox>

        {/* CARE NOTES */}
        <CardBox title="บันทึกการดูแลวันนี้" pill="สำหรับผู้ดูแล">
          <ul className="notes-list">
            <li>
              <span className="dot-status dot-green"></span>
              <div>
                <div className="note-title">อารมณ์โดยรวมดี</div>
                <div className="note-sub">
                  ยิ้มแย้ม พูดคุยได้ตามปกติ ไม่มีอาการซึมเศร้าหรือกังวลชัดเจน
                </div>
              </div>
            </li>
            <li>
              <span className="dot-status dot-blue"></span>
              <div>
                <div className="note-title">การทรงตัวและการเดิน</div>
                <div className="note-sub">
                  เดินได้เองภายในบ้าน แนะนำให้คอยประคองเวลาเดินขึ้นลงบันได
                </div>
              </div>
            </li>
            <li>
              <span className="dot-status dot-muted"></span>
              <div>
                <div className="note-title">อาการผิดปกติ</div>
                <div className="note-sub">
                  วันนี้ยังไม่พบอาการหายใจติดขัด เจ็บหน้าอก หรือเวียนศีรษะรุนแรง
                </div>
              </div>
            </li>
          </ul>
        </CardBox>
      </section>
    </main>
  );
}
