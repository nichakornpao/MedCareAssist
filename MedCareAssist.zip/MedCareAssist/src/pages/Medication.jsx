import React, { useState, useEffect } from "react";

const STORAGE_KEY = "medcare_meds_full";

export default function Medication() {
  // โหลดข้อมูลครั้งแรก
  const [meds, setMeds] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  // ฟิลด์ของยา
  const [name, setName] = useState("");       // ชื่อยา
  const [type, setType] = useState("");       // ชนิดยา
  const [dose, setDose] = useState("");       // ขนาดยา
  const [period, setPeriod] = useState("");   // รอบเวลา (เช้า / กลางวัน / เย็น / ก่อนนอน)
  const [time, setTime] = useState("");       // เวลาเตือน
  const [note, setNote] = useState("");       // หมายเหตุ

  // บันทึกลง localStorage ทุกครั้งที่ meds เปลี่ยน
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(meds));
  }, [meds]);

  const addMed = () => {
    if (!name.trim()) {
      alert("กรุณากรอกชื่อยา");
      return;
    }

    const newMed = {
      id: Date.now(),
      name: name.trim(),
      type,
      dose,
      period,
      time: time || "",
      note,
    };

    setMeds([...meds, newMed]);

    // เคลียร์ฟอร์ม
    setName("");
    setType("");
    setDose("");
    setPeriod("");
    setTime("");
    setNote("");
  };

  const deleteMed = (id) => {
    setMeds(meds.filter((m) => m.id !== id));
  };

  // แปลง "เช้า / กลางวัน / เย็น / ก่อนนอน" ไปเป็น class สี
  const getPeriodClass = (p) => {
    switch (p) {
      case "เช้า":
        return "pill pill-morning";
      case "กลางวัน":
        return "pill pill-noon";
      case "เย็น":
        return "pill pill-evening";
      case "ก่อนนอน":
        return "pill pill-night";
      default:
        return "pill";
    }
  };

  return (
    <main className="container dashboard">
      <section className="page-header">
        <div>
          <h1 className="page-title">จัดการยา</h1>
          <p className="page-sub">
            เพิ่มข้อมูลยา | เวลาทาน | ประเภท | วิธีใช้ | แจ้งเตือน
          </p>
        </div>
      </section>

      {/* ฟอร์มเพิ่มยา */}
      <section className="card">
        <h3>เพิ่มรายการยาใหม่</h3>

        <input
          className="input"
          placeholder="ชื่อยา เช่น Metformin"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <select
          className="input"
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          <option value="">เลือกชนิดยา</option>
          <option value="ยาเม็ด">ยาเม็ด</option>
          <option value="ยาน้ำ">ยาน้ำ</option>
          <option value="ยาฉีด">ยาฉีด</option>
          <option value="ยาทาผิว">ยาทาผิว</option>
          <option value="ยาป้ายตา/จมูก">ยาป้ายตา/จมูก</option>
        </select>

        <input
          className="input"
          placeholder="ขนาดยา เช่น 500 mg"
          value={dose}
          onChange={(e) => setDose(e.target.value)}
        />

        <select
          className="input"
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
        >
          <option value="">เลือกรอบการทานยา</option>
          <option value="เช้า">เช้า</option>
          <option value="กลางวัน">กลางวัน</option>
          <option value="เย็น">เย็น</option>
          <option value="ก่อนนอน">ก่อนนอน</option>
        </select>

        <input
          type="time"
          className="input"
          value={time}
          onChange={(e) => setTime(e.target.value)}
        />

        <textarea
          className="input"
          placeholder="หมายเหตุ เช่น ต้องทานพร้อมอาหาร / ห้ามท้องว่าง"
          value={note}
          onChange={(e) => setNote(e.target.value)}
        />

        <button className="btn-primary" onClick={addMed}>
          + เพิ่มยา
        </button>
      </section>

      {/* ตารางยา */}
      <section className="card">
        <h3>รายการยาทั้งหมด</h3>

        {meds.length === 0 && (
          <p className="page-sub">ยังไม่มีรายการยา ลองเพิ่มด้านบนได้เลย</p>
        )}

        <div className="med-table">
          <div className="med-header">
            <span>ชื่อยา</span>
            <span>ประเภท</span>
            <span>ขนาดยา</span>
            <span>รอบเวลา</span>
            <span>เวลาแจ้งเตือน</span>
            <span>หมายเหตุ</span>
            <span></span>
          </div>

          {meds.map((m) => (
            <div key={m.id} className="med-row">
              <span>{m.name}</span>
              <span>{m.type}</span>
              <span>{m.dose}</span>

              {/* pill มีสีตามช่วงเวลา */}
              <span>
                {m.period ? (
                  <span className={getPeriodClass(m.period)}>{m.period}</span>
                ) : (
                  "-"
                )}
              </span>

              <span>{m.time || "-"}</span>
              <span>{m.note}</span>

              <button className="btn-danger" onClick={() => deleteMed(m.id)}>
                ลบ
              </button>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
