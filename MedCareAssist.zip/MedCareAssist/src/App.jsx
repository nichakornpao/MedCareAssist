// src/App.jsx
import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";

// หน้าเลือกบทบาท
import RoleSelect from "./pages/RoleSelect";

// หน้าเดิมที่ยูมีอยู่
import Dashboard from "./pages/Dashboard";
import Medication from "./pages/Medication";
import Profile from "./pages/Profile";

// โหมดผู้ป่วย
import PatientHome from "./pages/patient/PatientHome";

// โหมดผู้ดูแล
import CaregiverDashboard from "./pages/caregiver/CaregiverDashboard";
import CaregiverGPS from "./pages/caregiver/CaregiverGPS";
import CaregiverSymptoms from "./pages/caregiver/CaregiverSymptoms";

// โหมดคลินิก
import ClinicReports from "./pages/clinic/ClinicReports";

export default function App() {
  return (
    <div className="app-shell">
      <Navbar />

      <Routes>
        {/* หน้าเลือกบทบาท */}
        <Route path="/" element={<RoleSelect />} />

        {/* ผู้ป่วย */}
        <Route path="/patient" element={<PatientHome />} />

        {/* ผู้ดูแล */}
        <Route path="/caregiver" element={<CaregiverDashboard />} />
        <Route path="/caregiver/gps" element={<CaregiverGPS />} />
        <Route path="/caregiver/symptoms" element={<CaregiverSymptoms />} />

        {/* คลินิก */}
        <Route path="/clinic" element={<ClinicReports />} />

        {/* หน้าอื่น ๆ ที่อยากเก็บไว้ใช้ */}
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/meds" element={<Medication />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </div>
  );
}
