// src/components/Navbar.jsx
import React from "react";
import { Link, useLocation } from "react-router-dom";
import logo from "../assets/logo.png";

export default function Navbar() {
  const loc = useLocation();

  const isActive = (path) =>
    loc.pathname === path ? "nav-link nav-link-active" : "nav-link";

  return (
    <header className="container header">
      <div className="brand">
        <div className="logo">
          {logo ? (
            <img src={logo} alt="logo" className="logo-img" />
          ) : (
            <span className="logo-mark">MC</span>
          )}
        </div>

        <div className="brand-text">
          <div className="brand-title">MedCare Assist</div>
          <div className="brand-sub">ระบบช่วยดูแลผู้ป่วยและจัดการการทานยา</div>
        </div>
      </div>

      {/* ---------- แก้เฉพาะส่วนนี้เท่านั้น ---------- */}
      <nav className="nav">
        <Link to="/" className={isActive("/")}>
          เลือกโหมด
        </Link>

        <Link to="/caregiver" className={isActive("/caregiver")}>
          ผู้ดูแล
        </Link>

        <Link to="/patient" className={isActive("/patient")}>
          ผู้ป่วย
        </Link>

        <Link to="/clinic" className={isActive("/clinic")}>
          คลินิก
        </Link>

        <Link to="/meds" className={isActive("/meds")}>
          ยาและการทานยา
        </Link>

        <Link to="/profile" className={isActive("/profile")}>
          โปรไฟล์
        </Link>
      </nav>
      {/* -------------------------------------------- */}
    </header>
  );
}
