// src/components/CardBox.jsx
import React from "react";

export default function CardBox({ title, children, pill }) {
  return (
    <section className="card">
      <div className="section-header">
        <h3>{title}</h3>
        {pill && <span className="section-pill">{pill}</span>}
      </div>
      {children}
    </section>
  );
}
