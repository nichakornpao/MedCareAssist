// src/components/StatCard.jsx
import React from "react";

export default function StatCard({ label, value, unit, status, accent }) {
  return (
    <div className="stat-card">
      <div className="stat-header">
        <span className="stat-label">{label}</span>
        {status && <span className={`stat-status stat-${accent}`}>{status}</span>}
      </div>
      <div className="stat-value-row">
        <span className="stat-value">{value}</span>
        {unit && <span className="stat-unit">{unit}</span>}
      </div>
    </div>
  );
}
